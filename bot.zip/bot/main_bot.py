import random
import string
import re
import time
from datetime import datetime, timedelta
import threading
import os
import platform
msg = "i am currently AFK and this is a new feature i added to my custom client so if it breaks and starts spamming you sorry"
lcread = ""
ai = False
queue = None
current_equation_time = list(range(1, 2400))
target = 12 + import("enter PM hours: ")
week = 0
best = 2147483647
trys = 0
queue_spot = 0
dm = 0
dp = 0
result = 0
os_name = platform.system()
def queue_time_predictor(queue, current_equation_time):
    return ((queue / 1.1) / 60) + current_equation_time
if week == 0:
    aiout = open("ai_output_day.txt", "r")
if week == 1:
    aiout = open("ai_output_end.txt", "r")
aiout_lines = aiout.readlines()
aiout.close()
for queue_incrementation in aiout_lines:
    time_str = queue_incrementation.split('-')[-1]  # '0:1:30'
    s, h, m = map(int, time_str.split(':'))
    cet = h + m / 60 + s / 3600
    queue_incrementation = int(queue_incrementation.split()[0])
    queue_incrementation = int(queue_incrementation)
    trys = trys + 1
    estimated_time = queue_time_predictor(int(queue_incrementation), cet)
    estimated_time_difference = estimated_time + cet
    estimated_time_difference = abs(estimated_time_difference - target)
    if best == None:
        best = estimated_time_difference
        best_cet = cet
        best_estimated_time = estimated_time_difference
        best_queue_incrementation = queue_incrementation
    else:
        if best > estimated_time_difference:
            best = estimated_time_difference
            best_cet = cet
            best_estimated_time = estimated_time
            best_queue_incrementation = queue_incrementation
cet_hours = int(best_cet)
cet_minutes = int((best_cet - cet_hours) * 60)
print("join queue time " + cet_hours + ":" + cet_minutes)
print("join game time", target)
if ai == True:
    import joblib # ai
    import pandas as pd # ai
    model = joblib.load("2b2t_queue_model.pkl") # ai
while True:
    now = datetime.now()
    hour = now.hour
    minute = now.minute
    a = now.replace(hour=cet_hours, minute=cet_minutes, second=1)
    if now > a:
        c = open("tochat.txt", "w", encoding='utf-8')
        c.write(".disconnect")
        c.close()
    else:
        break
    time.sleep(100)
def data():
    global lcread
    global dp
    global result
    while True:
        c = open("command.txt", "w", encoding='utf-8')
        c.write("queue")
        c.close()
        time.sleep(0.1)
        lc = open(r"lastchat2.txt" , "r", encoding='utf-8')
        lcread = lc.read()
        lc.close()
        if "2b2t queue lengths: normal: " in lcread:
            match = re.search(r'2b2t queue lengths: normal: (\d+)', lcread)
            if match:
                result = int(match.group(1))

                today = datetime.today()
                m = today.month
                d = today.day
                y = today.year

                up = open("queue_data-" + str(m) + "-" + str(d) + "-" + str(y) + ".txt", "a", encoding='utf-8')
                now = datetime.now()
                day_of_week = now.strftime("%A")
                hour = now.hour
                minute = now.minute
                second = now.second
                up.write(str(result) + "  " + str(day_of_week) + "-" + str(hour) + ":" + str(minute) + ":" + str(second) + "\n")
                dp = dp + 1
                up.close()
                time.sleep(1.5)
            else:
                pass
        else:
            pass
def position_in_queue():
    global queue_spot
    while True:
        lc = open(r"lastchat.txt" , "r", encoding='utf-8')
        lcread = lc.read()
        lc.close()
        if "Position in queue: " in lcread:
            match = re.search(r'\d+', lcread)
            if match:
                queue_spot = int(match.group())
            else:
                pass
        else:
            pass
        time.sleep(1)
def afker():
    global dm
    rng = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(10))
    while True:
        lc = open(r"lastchat.txt" , "r", encoding='utf-8')
        lcread = lc.read()
        lc.close()
        if "whispers:" in  lcread:
            time.sleep(6)
            c = open(r"command.txt", "w")
            c.write("r " + msg + " " + rng)
            dm = dm + 1
            c.close()
            rng = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(10))
            time.sleep(1)
            lcw = open(r"lastchat.txt", "w")
            lcw.write("not")
            lcw.close()
            time.sleep(6)
        time.sleep(0.05)

data_t = threading.Thread(target=data)
data_t.start()
position_in_queue_t = threading.Thread(target=position_in_queue)
position_in_queue_t.start()
afker_t = threading.Thread(target=afker)
afker_t.start()
print("startig...")
time.sleep(10)
queue_spot_start = queue_spot
start_time = time.time()
while True:
    time_now = time.time()
    if ai == True:
        week = datetime.today().weekday() # ai
        now = datetime.now() # ai
        hour = now.hour # ai
        minute = now.minute # ai
        second = now.second # ai
        if week < 5: # ai
            is_weekend = 0 # ai
        else: # ai
            is_weekend = 1 # ai
        X_input = pd.DataFrame([[is_weekend, hour, minute, second]], columns=["IsWeekend", "Hour", "Minute", "Second"]) # ai
        prediction = model.predict(X_input) # ai
    if ai == False:
        prediction = [0.01, "null"] # no ai
    t2p = (queue_spot_start - queue_spot) / (time_now - start_time) * 60
    print("""
=========================
pos   :""", queue_spot , """
t2p   :""", t2p, """
ai    :""", prediction[0], """
ai_off:""", abs(float(prediction[0]) - result), """
dp    :""", dp ,"""
dm    :""", dm ,"""
=========================
logs:
""" + lcread)
    time.sleep(0.4)
    if os_name == "Windows":
        os.system("cls")
    else:
        os.system("clear")
